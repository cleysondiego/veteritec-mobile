package br.com.veteritec.utils;

public class LocalStorage {
}
